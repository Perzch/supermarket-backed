package com.melody.supermarket.exception;

public class ExistException extends RuntimeException{
    public ExistException() {
        super();
    }

    public ExistException(String s) {
        super(s);
    }
}
