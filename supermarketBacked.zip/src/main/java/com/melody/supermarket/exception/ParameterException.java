package com.melody.supermarket.exception;

public class ParameterException extends RuntimeException {
    public ParameterException() {
        super();
    }

    public ParameterException(String s) {
        super(s);
    }
}
